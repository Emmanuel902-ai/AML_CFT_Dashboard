import dash
from dash import dcc, html, dash_table, Input, Output, State, callback
import pandas as pd
import numpy as np
import joblib
import plotly.express as px
import os
import base64
import io
from sklearn.metrics import classification_report
from sklearn.preprocessing import StandardScaler

# Initialize app
app = dash.Dash(__name__, suppress_callback_exceptions=True)
server = app.server

# Load models and metadata
MODEL_PATH = "/home/students/Documents/AML CFT_dashboard_project/models"
DATA_PATH = "/home/students/Documents/AML CFT_dashboard_project/notebooks/data/processed"
TOP_FEATURES = joblib.load(os.path.join(DATA_PATH, "top_features.pkl"))
SCALER = joblib.load(os.path.join(MODEL_PATH, "scaler.pkl"))
SCALER_SAMPLE = joblib.load(os.path.join(MODEL_PATH, "scaler_sample.pkl"))

models = {
    "Random Forest": joblib.load(os.path.join(MODEL_PATH, "random_forest.pkl")),
    "Logistic Regression": joblib.load(os.path.join(MODEL_PATH, "logistic_regression.pkl")),
    "HDBSCAN": joblib.load(os.path.join(MODEL_PATH, "hdbscan_model.pkl")),
    "Isolation Forest": joblib.load(os.path.join(MODEL_PATH, "isolation_forest.pkl")),
}

# Numerical columns for scaling
numerical_cols = ['Amount', 'Recipient_diversity', 'Sender_diversity', 'Daily_frequency', 
                  'Avg_velocity', 'Total_inflow', 'Total_outflow', 'Inflow_Outflow_Ratio', 
                  'Txn_sequence', 'Rolling_avg_amt', 'Weekday', 'Day', 'Month']

# Categorical columns for encoding
categorical_cols = ['Payment_currency', 'Received_currency', 'Sender_bank_location', 
                    'Receiver_bank_location', 'Payment_type']

# Layout
app.layout = html.Div([
    html.Div([
        html.H2("AML Detection Dashboard", style={"textAlign": "center"}),
        html.Div([
            html.Label("Select Model:", style={"fontWeight": "bold"}),
            dcc.Dropdown(
                id="model_selector",
                options=[{"label": name, "value": name} for name in models.keys()],
                value="Random Forest",
                style={"width": "50%"}
            ),
        ], style={"paddingBottom": "20px"}),
        html.Div([
            html.Label("Upload a CSV File:", style={"fontWeight": "bold"}),
            dcc.Upload(
                id="upload_data",
                children=html.Div(["Drag and Drop or Click to Upload"]),
                style={
                    'width': '100%', 'height': '60px', 'lineHeight': '60px',
                    'borderWidth': '1px', 'borderStyle': 'dashed',
                    'borderRadius': '5px', 'textAlign': 'center',
                    'marginBottom': '20px'
                },
                multiple=False
            )
        ]),
    ], style={"maxWidth": "900px", "margin": "auto"}),
    html.Div(id='output_metrics', style={"padding": "20px"}),
    html.Div(id='prediction_table', style={"padding": "20px"}),
    dcc.Graph(id='pie_chart', style={"padding": "20px"})
])

@callback(
    [Output('output_metrics', 'children'),
     Output('prediction_table', 'children'),
     Output('pie_chart', 'figure')],
    [Input('upload_data', 'contents')],
    [State('upload_data', 'filename'),
     State('model_selector', 'value')]
)
def update_output(contents, filename, model_name):
    if contents is None:
        return ["Please upload a file."], None, {}

    content_type, content_string = contents.split(',')
    decoded = base64.b64decode(content_string)

    try:
        # Read CSV
        df = pd.read_csv(io.StringIO(decoded.decode('utf-8-sig')))
    except Exception as e:
        return [f"❌ Failed to parse CSV: {e}"], None, {}

    # Save original for display
    df_original = df.copy()

    # Check if CSV is preprocessed (has top features)
    if set(TOP_FEATURES).issubset(df.columns):
        # Preprocessed CSV (e.g., sample_for_dashboard.csv)
        X = df[TOP_FEATURES].copy()
        y_true = df['Is_laundering'] if 'Is_laundering' in df.columns else None
    else:
        # Raw CSV, preprocess to match training pipeline
        try:
            df['Date'] = pd.to_datetime(df['Date'], errors='coerce')
            df['Time'] = pd.to_datetime(df['Time'], format='%H:%M:%S', errors='coerce')
            df = df.sort_values(by=['Sender_account', 'Date', 'Time'])
            df['Total_inflow'] = df.groupby('Receiver_account')['Amount'].cumsum()
            df['Total_outflow'] = df.groupby('Sender_account')['Amount'].cumsum()
            df['Inflow_Outflow_Ratio'] = df['Total_inflow'] / (df['Total_outflow'] + 1e-6)
            df['Recipient_diversity'] = df.groupby('Sender_account')['Receiver_account'].transform(
                lambda x: x.rolling(window=100, min_periods=1).nunique())
            df['Sender_diversity'] = df.groupby('Receiver_account')['Sender_account'].transform(
                lambda x: x.rolling(window=100, min_periods=1).nunique())
            df['Daily_frequency'] = df.groupby(['Sender_account', 'Date']).transform('size')
            df['Avg_velocity'] = df.groupby('Sender_account')['Daily_frequency'].transform(
                lambda x: x.rolling(window=7, min_periods=1).mean())
            df['Txn_sequence'] = df.groupby('Sender_account').cumcount() + 1
            df['Rolling_avg_amt'] = df.groupby('Sender_account')['Amount'].rolling(
                window=3, min_periods=1).mean().reset_index(0, drop=True)
            df['Hour'] = df['Time'].dt.hour
            df['Minute'] = df['Time'].dt.minute
            df['Weekday'] = df['Date'].dt.weekday
            df['Day'] = df['Date'].dt.day
            df['Month'] = df['Date'].dt.month
            df = df.drop(columns=['Time', 'Laundering_type'] if 'Laundering_type' in df.columns else ['Time'])
            df['Sender_account'] = df['Sender_account'].astype('int32')
            df['Receiver_account'] = df['Receiver_account'].astype('int32')
            df['Amount'] = df['Amount'].astype('float32')
            if 'Is_laundering' in df.columns:
                df['Is_laundering'] = df['Is_laundering'].astype('int8')
            for col in ['Recipient_diversity', 'Sender_diversity', 'Daily_frequency', 'Avg_velocity', 
                        'Total_inflow', 'Total_outflow', 'Inflow_Outflow_Ratio', 'Txn_sequence', 'Rolling_avg_amt']:
                df[col] = df[col].astype('float32')
            df = pd.get_dummies(df, columns=categorical_cols, drop_first=True)
            df[numerical_cols] = df[numerical_cols].fillna(df[numerical_cols].median(numeric_only=True))
            df[numerical_cols] = SCALER.transform(df[numerical_cols])
            y_true = df['Is_laundering'] if 'Is_laundering' in df.columns else None
            X = df.reindex(columns=TOP_FEATURES, fill_value=0)
        except Exception as e:
            return [f"❌ Preprocessing failed: {e}"], None, {}

    # Verify feature alignment
    if list(X.columns) != TOP_FEATURES:
        return [f"❌ Feature mismatch: Expected {TOP_FEATURES}, got {list(X.columns)}"], None, {}

    model = models[model_name]

    try:
        if model_name == "HDBSCAN":
            labels = model.fit_predict(X)
            y_pred = (labels == -1).astype(int)
        else:
            y_pred = model.predict(X)
            if model_name == "Isolation Forest":
                y_pred = np.where(y_pred == -1, 1, 0)
    except Exception as e:
        return [f"❌ Model prediction failed: {e}"], None, {}

    # Append predictions to original dataframe
    df_original['Prediction'] = y_pred

    # Metrics
    if y_true is not None:
        report = classification_report(y_true, y_pred, output_dict=True, zero_division=0)
        metrics = html.Div([
            html.H4("Model Performance Metrics"),
            html.P(f"Precision: {report['1']['precision']:.2f}"),
            html.P(f"Recall: {report['1']['recall']:.2f}"),
            html.P(f"F1 Score: {report['1']['f1-score']:.2f}"),
        ])
    else:
        metrics = html.Div([
            html.H4("Prediction Summary"),
            html.P(f"{sum(y_pred)} transactions predicted as laundering.")
        ])

    # Prediction table
    table = dash_table.DataTable(
        columns=[{"name": i, "id": i} for i in df_original.columns],
        data=df_original.head(50).to_dict('records'),
        style_table={'overflowX': 'auto'},
        page_size=10
    )

    # Pie chart
    fig = px.pie(df_original, names='Prediction', title='💡 Prediction Distribution')

    return metrics, table, fig

if __name__ == '__main__':
    app.run(debug=True, port=8051)